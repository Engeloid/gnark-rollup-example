﻿package rollup

import (
	// "hash"

	"fmt"
	"log"
	"math/rand"

	// . "rollup/src/tools"

	"github.com/consensys/gnark-crypto/ecc"
	"github.com/consensys/gnark-crypto/ecc/bn254/fr"
	"github.com/consensys/gnark-crypto/ecc/bn254/twistededwards/eddsa"
	"github.com/consensys/gnark/backend/groth16"
	"github.com/consensys/gnark/constraint"
	"github.com/consensys/gnark/frontend"
	"github.com/consensys/gnark/frontend/cs/r1cs"
	"github.com/ethereum/go-ethereum/common"
)

const (
	fileToProof = "./test/rollupg16.proof"
	fileToPK    = "./test/rollupg16.pk"
	fileToCS    = "./test/rollupg16.cs"
)

// ---------- Rollup ---------
// Rollup represents a rollup, NOTE: not used yet
type Rollup struct {
	// contract stuff
	op       Operator
	userKeys []eddsa.PrivateKey // list of private keys
	// Mapping of public keys to rollup public keys
	contractBalance int64

	// Network stuff
	networkURL      string         // network URL, e.g.: "HTTP://127.0.0.1:7545"
	contractAddress common.Address // Ethereum Address of the rollup contract
}

// func SetupRollupProofAndContract(fileNameProof string, fileNamePK string, fileNameCS string) (groth16.Proof, error) {
func (o *Operator) SetupRollupProofAndContract() (constraint.ConstraintSystem, groth16.ProvingKey, groth16.VerifyingKey, error) {
	// compiles our circuit into a R1CS
	var circuit Circuit

	_ccs, err := frontend.Compile(ecc.BN254.ScalarField(), r1cs.NewBuilder, &circuit, frontend.IgnoreUnconstrainedInputs())
	if err != nil {
		log.Fatalln(err)
	}

	fmt.Printf("Circuit sender key: %x\n", circuit.PublicKeysSender[0].A.X)
	//fmt.Printf("constraint system: %v\n", ccs)
	// err := SaveCSToFile(ccs, fileToCS)

	// groth16 zkSNARK: Setup
	_pk, _vk, err := groth16.Setup(_ccs)
	if err != nil {
		log.Fatalln(err)
	}
	// err = SavePKToFile(pk, fileToPK)

	// -------- witness definition ---------

	return _ccs, _pk, _vk, err
}

func CreateOP(nbAccounts int) (Operator, []eddsa.PrivateKey) {
	// TODO: create Rollup object and create respective smart contract
	op, userKeys := genOperator(nbAccounts)

	return op, userKeys
}

func (o *Operator) MakeTransfer(amount uint64, fromPriv eddsa.PrivateKey, from, to Account) error {

	// create the transfer and sign it
	transfer := NewTransfer(amount, from.PubKey, to.PubKey, from.Nonce)
	transfer.Sign(fromPriv, o.H)

	err := o.UpdateState(transfer, 0)
	if err != nil {
		return err
	}

	return nil
}

// ReadAcc reads the account located at index i
func (o *Operator) ReadAcc(i uint64) (Account, error) {
	var res Account
	err := Deserialize(&res, o.State[int(i)*SizeAccount:int(i)*SizeAccount+SizeAccount])
	if err != nil {
		return res, err
	}
	return res, nil
}

// returns a single account on the rollup
func genAccount(i int) (Account, eddsa.PrivateKey) {

	var acc Account
	var rnd fr.Element
	var privkey eddsa.PrivateKey

	// create account, the i-th account has a balance of 20+i
	acc.index = uint64(i)
	acc.Nonce = uint64(i)
	acc.balance.SetUint64(uint64(i) + 20)
	rnd.SetUint64(uint64(i))
	src := rand.NewSource(int64(i))
	r := rand.New(src)

	pkey, err := eddsa.GenerateKey(r)
	if err != nil {
		panic(err)
	}
	privkey = *pkey

	acc.PubKey = privkey.PublicKey

	return acc, privkey
}

// Returns a newly created operator and the private keys of the associated accounts
func genOperator(nbAccounts int) (Operator, []eddsa.PrivateKey) {

	operator := NewOperator(nbAccounts)

	operator.Witnesses.allocateSlicesMerkleProofs()

	userAccounts := make([]eddsa.PrivateKey, nbAccounts)

	// randomly fill the accounts
	for i := 0; i < nbAccounts; i++ {

		acc, privkey := genAccount(i)

		// fill the index map of the operator
		b := acc.PubKey.A.X.Bytes()
		operator.AccountMap[string(b[:])] = acc.index

		// fill user accounts list
		userAccounts[i] = privkey
		baccount := acc.Serialize()

		copy(operator.State[SizeAccount*i:], baccount)

		// create the list of hashes of account
		operator.H.Reset()
		operator.H.Write(acc.Serialize())
		buf := operator.H.Sum([]byte{})
		copy(operator.HashState[operator.H.Size()*i:], buf)
	}

	return operator, userAccounts

}

func (o *Operator) ReadAccounts() ([]Account, error) {
	var i uint64
	res := make([]Account, o.nbAccounts)
	for i = 0; i < uint64(o.nbAccounts); i++ {
		res[i], _ = o.readAccount(i)
	}

	return res, nil
}

func (o *Operator) GetNbAccounts() uint64 {

	return uint64(o.nbAccounts)
}
