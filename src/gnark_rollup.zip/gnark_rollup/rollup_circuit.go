﻿/*
Copyright © 2020 ConsenSys

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package rollup

import (
	"fmt"

	"github.com/consensys/gnark/frontend"
	"github.com/consensys/gnark/std/accumulator/merkle"
	"github.com/consensys/gnark/std/hash/mimc"
	"github.com/consensys/gnark/std/signature/eddsa"
)

// Circuit "toy" rollup circuit where an operator can generate a proof that he processed
// some transactions
type RollupCircuit struct {
	// ---------------------------------------------------------------------------------------------
	// SECRET INPUTS

	// list of accounts involved before update and their public keys
	SenderAccountsBeforeID        [BatchSizeCircuit]frontend.Variable
	SenderAccountsBeforeNonce     [BatchSizeCircuit]frontend.Variable
	SenderAccountsBeforeBalance   [BatchSizeCircuit]frontend.Variable
	SenderAccountsBeforePK        [BatchSizeCircuit]eddsa.PublicKey
	ReceiverAccountsBeforeID      [BatchSizeCircuit]frontend.Variable
	ReceiverAccountsBeforeNonce   [BatchSizeCircuit]frontend.Variable
	ReceiverAccountsBeforeBalance [BatchSizeCircuit]frontend.Variable
	ReceiverAccountsBeforePK      [BatchSizeCircuit]eddsa.PublicKey
	PublicKeysSender              [BatchSizeCircuit]eddsa.PublicKey

	// list of accounts involved after update and their public keys
	SenderAccountsAfterID        [BatchSizeCircuit]frontend.Variable
	SenderAccountsAfterNonce     [BatchSizeCircuit]frontend.Variable
	SenderAccountsAfterBalance   [BatchSizeCircuit]frontend.Variable
	SenderAccountsAfterPK        [BatchSizeCircuit]eddsa.PublicKey
	ReceiverAccountsAfterID      [BatchSizeCircuit]frontend.Variable
	ReceiverAccountsAfterNonce   [BatchSizeCircuit]frontend.Variable
	ReceiverAccountsAfterBalance [BatchSizeCircuit]frontend.Variable
	ReceiverAccountsAfterPK      [BatchSizeCircuit]eddsa.PublicKey
	PublicKeysReceiver           [BatchSizeCircuit]eddsa.PublicKey

	// list of transactions
	TransferAmount  [BatchSizeCircuit]frontend.Variable
	TransferNonce   [BatchSizeCircuit]frontend.Variable
	TransferSPubKey [BatchSizeCircuit]eddsa.PublicKey
	TransferRPubKey [BatchSizeCircuit]eddsa.PublicKey
	TransferSig     [BatchSizeCircuit]eddsa.Signature

	// list of proofs corresponding to sender and receiver accounts
	MerkleProofReceiverBefore [BatchSizeCircuit]merkle.MerkleProof
	MerkleProofReceiverAfter  [BatchSizeCircuit]merkle.MerkleProof
	MerkleProofSenderBefore   [BatchSizeCircuit]merkle.MerkleProof
	MerkleProofSenderAfter    [BatchSizeCircuit]merkle.MerkleProof
	LeafReceiver              [BatchSizeCircuit]frontend.Variable
	LeafSender                [BatchSizeCircuit]frontend.Variable

	// ---------------------------------------------------------------------------------------------
	// PUBLIC INPUTS

	// list of root hashes
	RootHashesBefore [BatchSizeCircuit]frontend.Variable `gnark:",public"`
	RootHashesAfter  [BatchSizeCircuit]frontend.Variable `gnark:",public"`
}

func (circuit *RollupCircuit) postInit2(api frontend.API) error {

	for i := 0; i < BatchSizeCircuit; i++ {

		// setting the sender accounts before update

		fmt.Printf("circuit sender in init: %x\n", circuit.PublicKeysSender[i])
		circuit.SenderAccountsBeforePK[i] = circuit.PublicKeysSender[i]

		// setting the sender accounts after update
		circuit.SenderAccountsAfterPK[i] = circuit.PublicKeysSender[i]

		// setting the receiver accounts before update
		circuit.ReceiverAccountsBeforePK[i] = circuit.PublicKeysReceiver[i]

		// setting the receiver accounts after update
		circuit.ReceiverAccountsAfterPK[i] = circuit.PublicKeysReceiver[i]

		// setting the transfers
		circuit.TransferNonce[i] = circuit.SenderAccountsBeforeNonce
		circuit.TransferSPubKey[i] = circuit.PublicKeysSender[i]
		circuit.TransferRPubKey[i] = circuit.PublicKeysReceiver[i]

		// allocate the slices for the Merkle proofs
		circuit.allocateSlicesMerkleProofs()

	}
	return nil
}

func (circuit *RollupCircuit) allocateSlicesMerkleProofs() {

	for i := 0; i < BatchSizeCircuit; i++ {
		// allocating slice for the Merkle paths
		circuit.MerkleProofReceiverBefore[i].Path = make([]frontend.Variable, depth)
		circuit.MerkleProofReceiverAfter[i].Path = make([]frontend.Variable, depth)
		circuit.MerkleProofSenderBefore[i].Path = make([]frontend.Variable, depth)
		circuit.MerkleProofSenderAfter[i].Path = make([]frontend.Variable, depth)
	}

}

// Define declares the circuit's constraints
func (circuit *RollupCircuit) Define(api frontend.API) error {

	if err := circuit.postInit2(api); err != nil {
		return err
	}
	// hash function for the merkle proof and the eddsa signature
	hFunc, err := mimc.NewMiMC(api)
	if err != nil {
		return err
	}

	// verifications of:
	// - Merkle proofs of the accounts
	// - the signatures
	// - accounts' balance consistency
	for i := 0; i < BatchSizeCircuit; i++ {

		// the root hashes of the Merkle path must match the public ones given in the circuit
		api.AssertIsEqual(circuit.RootHashesBefore[i], circuit.MerkleProofReceiverBefore[i].RootHash)
		api.AssertIsEqual(circuit.RootHashesBefore[i], circuit.MerkleProofSenderBefore[i].RootHash)
		api.AssertIsEqual(circuit.RootHashesAfter[i], circuit.MerkleProofReceiverAfter[i].RootHash)
		api.AssertIsEqual(circuit.RootHashesAfter[i], circuit.MerkleProofSenderAfter[i].RootHash)

		// the leafs of the Merkle proofs must match the index of the accounts
		api.AssertIsEqual(circuit.ReceiverAccountsBeforeID[i], circuit.LeafReceiver[i])
		api.AssertIsEqual(circuit.ReceiverAccountsAfterID[i], circuit.LeafReceiver[i])
		api.AssertIsEqual(circuit.SenderAccountsBeforeID[i], circuit.LeafSender[i])
		api.AssertIsEqual(circuit.SenderAccountsAfterID[i], circuit.LeafSender[i])

		// Reset the hash state!
		hFunc.Reset()
		/*
			// the signature is on h(nonce ∥ amount ∥ senderpubKey (x&y) ∥ receiverPubkey(x&y))
			hFunc.Write(circuit.TransferNonce[i], circuit.TransferAmount[i], circuit.TransferSPubKey[i].A.X, circuit.TransferSPubKey[i].A.Y, circuit.TransferRPubKey[i].A.X, circuit.TransferRPubKey[i].A.Y)
			htransfer := hFunc.Sum()

			curve, err := twistededwards.NewEdCurve(api, tedwards.BN254)
			if err != nil {
				return err
			}

			hFunc.Reset()
			err = eddsa.Verify(curve, circuit.TransferSig[i], htransfer, circuit.TransferSPubKey[i], &hFunc)
			if err != nil {
				return err
			} */
	}

	return nil
}
